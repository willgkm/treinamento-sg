angular.module("exercicioUm", ["ngMessages","ngRoute"]);
