package Exercicio03.Sg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SgApplicationTests {

	@Test
	void contextLoads() {
	}

}
