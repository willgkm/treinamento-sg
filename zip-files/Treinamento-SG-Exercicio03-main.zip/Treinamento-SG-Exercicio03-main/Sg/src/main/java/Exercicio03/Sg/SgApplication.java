package Exercicio03.Sg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SgApplication {

	public static void main(String[] args) {
		SpringApplication.run(SgApplication.class, args);
	}

}
