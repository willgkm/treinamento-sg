package sg.exercicio04;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exercicio04Application {

    public static void main(String[] args) {
        SpringApplication.run(Exercicio04Application.class, args);
    }

}
