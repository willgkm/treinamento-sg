# Treinamento-SG-exercicio04


Gerenciamento de Biblioteca

Construa um sistema que permita o cadastro de Livros e Periódicos (Revistas, Jornais), de Usuários e o registro de Empréstimos.

    Cada Usuário possui um limite N de itens que podem ser emprestados ao mesmo tempo.
    O sistema deve controlar as datas de devolução e possíveis atrasos.
    Para os atrasos deve ser gerada uma multa diária.
    Um Usuário só pode realizar um novo empréstimo se não tiver atingido o limite N, se não tiver nenhum item em atraso e se não tiver nenhuma multa pendente.
