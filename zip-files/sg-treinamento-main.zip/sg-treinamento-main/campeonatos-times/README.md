# Campeonatos e Times
Crie um sistema que seja capaz de registrar inúmeros Times presentes em um ou mais Campeonatos simultânetos.

O Campeonato deve possuir data inicial, data final, quais os times que participam do Campeonato e a colocação deles com base no sistema de pontos.