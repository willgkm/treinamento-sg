# Gerenciamento de Orçamentos para Mecânica

O Sistema deverá suportar o cadastro de Clientes e Veículos. Quando um Veículo der entrada na oficina, um Funcionário fará a Avaliação listando quais os Serviços necessários no Veículo, gerando um Orçamento.

Se o Cliente aprovar o Orçamento, então os serviços começam a ser feitos. O número de dias trabalhados deverá ser computado.