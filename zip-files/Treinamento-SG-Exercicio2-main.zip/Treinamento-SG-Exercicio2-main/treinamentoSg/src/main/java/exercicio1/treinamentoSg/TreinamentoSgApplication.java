package exercicio1.treinamentoSg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TreinamentoSgApplication {

	public static void main(String[] args) {
		SpringApplication.run(TreinamentoSgApplication.class, args);
	}

}
