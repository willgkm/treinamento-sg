package exercicio1.treinamentoSg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TreinamentoSgApplicationTests {

	@Test
	void contextLoads() {
	}

}
