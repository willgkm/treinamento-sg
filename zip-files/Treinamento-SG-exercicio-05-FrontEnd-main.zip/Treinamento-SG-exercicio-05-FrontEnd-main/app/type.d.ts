
declare module 'angular'
declare module 'moment'
declare module '*.html'
declare module '*.scss'
declare module '*.svg'


