
class physiscalAccountDeleteController {

  constructor(
    public $scope,
    public $state,
    public $interval,
  ) { }


}

physiscalAccountDeleteController['$inject'] = [
  '$scope',
  '$state',
  '$interval',
]


export default physiscalAccountDeleteController;