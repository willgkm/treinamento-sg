package banco.exercicio05;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exercicio05Application {

    public static void main(String[] args) {
        SpringApplication.run(Exercicio05Application.class, args);
    }

}
