package banco.exercicio05.movimentacao.projection;

public interface MovimentacaoProjection {
//    double getId();
//    getSaldo();
//    getLimiteCredito();
//    getJurosDaConta();
//    getConta();
}
