package banco.exercicio05.registro.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ExtratoDTO {

    private Long contaId;
    private Long dias;
}
